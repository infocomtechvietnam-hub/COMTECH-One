# COMTECH One

Nền tảng số COMTECH Việt Nam. Giai đoạn 1: **website công khai** (www.comtechvietnam.vn) + **API tiếp nhận lead** vào cơ sở dữ liệu trung tâm. CRM, Workspace và Mobile kết nối ở các giai đoạn sau, dùng chung dữ liệu.

Tài liệu nguồn: MASTER PROMPT V4.0, Technical Specification V2.0. Quyết định kiến trúc: [`docs/adr/ADR-001-comtech-one-website-first.md`](docs/adr/ADR-001-comtech-one-website-first.md).

## Cấu trúc

| Thư mục | Nội dung |
|---|---|
| `apps/web` | Website Next.js 16 (SSG). 14 loại trang, 51 trang dựng sẵn ở chế độ xem trước |
| `apps/api` | NestJS 12: `POST /api/v1/public/leads`, `/health`, `/ready`; `src/worker.ts` gửi email lead qua outbox |
| `packages/contracts` | Schema form lead (zod), danh mục, mã lỗi: một nguồn quy tắc cho web và API |
| `packages/content` | Nội dung website + trạng thái xác minh + sổ duyệt `approvals.ts` |
| `packages/db` | Prisma 7 schema + migration SQL (`leads`, `code_sequences`, `domain_events`, `idempotency_keys`) |
| `docs/` | ADR, báo cáo rà soát G0, báo cáo kiểm tra nội dung |

## Chạy trên máy dev

Yêu cầu: Node 22, pnpm 10, Docker.

```bash
pnpm install
cp .env.example .env                  # chỉnh nếu cần
pnpm db:up                            # Postgres 16 + Mailpit (xem email tại http://localhost:8025)
pnpm --filter @comtech/contracts build
pnpm db:generate && pnpm --filter @comtech/db build
pnpm db:migrate                       # áp migration

# Terminal 1: API
pnpm --filter @comtech/api build && node --env-file=.env apps/api/dist/main.js
# Terminal 2: worker email
node --env-file=.env apps/api/dist/worker.js
# Terminal 3: website (bản xem trước nội bộ, có nội dung chờ duyệt)
CONTENT_PREVIEW=true pnpm --filter @comtech/web dev
```

Mở http://localhost:3000.

## Kiểm thử

```bash
pnpm --filter @comtech/contracts test     # schema form, chuẩn hóa SĐT
pnpm --filter @comtech/content test       # quy tắc No Fake Data, sổ duyệt
TEST_DATABASE_URL=postgresql://... pnpm --filter @comtech/api test   # API + outbox trên Postgres thật
pnpm content:check                        # mục nội dung nào đã/chưa được lên production
```

## Hai chế độ website

| | Production (`CONTENT_PREVIEW=false`) | Xem trước (`CONTENT_PREVIEW=true`) |
|---|---|---|
| Nội dung | Chỉ mục đã duyệt + xác minh | Thêm mục chờ duyệt, nhãn "CHỜ DUYỆT" |
| Dữ liệu mẫu | Không bao giờ | Có, watermark "DỮ LIỆU MẪU" |
| Số liệu xung đột (9.674 trạm, địa chỉ) | Ẩn | Ẩn |
| Form lead | Khóa tới khi chính sách dữ liệu được duyệt pháp lý | Mở |
| Index công cụ tìm kiếm | Chỉ khi `APP_ENV=production` | Không |

## Duyệt nội dung (dành cho Product Owner)

1. Xem bản xem trước trên STAGING.
2. Sửa câu chữ trong `packages/content/src/data/*.ts` nếu cần.
3. Thêm id mục đã duyệt vào `packages/content/src/approvals.ts`, ví dụ:
   `'capability.t': { reviewed_by: 'Họ tên PO', reviewed_at: '2026-10-01' },`
4. Mở Pull Request. CI kiểm tra và build lại website.

Danh sách đầy đủ các mục và lý do đang bị chặn: [`docs/content-verification.md`](docs/content-verification.md).
